from graphwerk.trapimsg import addone_shrink

from graphwerk import trapimsg as kg

addone_shrink(99)

kg.addone_shrink(101)
