
def boing(n):
    print(", ".join(["boing" for i in range(0, n)]))
