
def copy_non_message_fields(orig_response: dict) -> dict:
    retval = {}
    # first copy everything except .fields
    retval = {k: orig_response[k] for k in orig_response if k != 'fields'}

    # then get everything in .fields except .data
    retval['fields'] = {k: orig_response['fields'][k] for k in orig_response['fields'] if k != 'data'}

    # next get everything in .fields.data except .message and .logs
    skip = {'message', 'logs'}
    retval['fields']['data'] = {k: orig_response['fields']['data'][k] for k in orig_response['fields']['data'] if k not in skip}
    return retval


# NOTE: This function collects only those nodes from the KG that are bound to the nodes specified in the QG.
# It doesn't collect the complete set of nodes obtained by following all edges/support graphs. When working
# with inferred query results, you will rarely want to use this function, if at all.
# Use collect_nodes_or_edge_collection() instead.
def collect_qg_nodes_for_res_elem(res_elem: dict, kg: dict, node_collection: dict) -> dict:
    for qg_node_vals in res_elem['node_bindings'].values():
        for elem in qg_node_vals:
            if 'id' in elem:
                node_id = elem['id']
                if node_id not in node_collection:
                    node_collection[node_id] = kg['nodes'][node_id]

    # For now, do not catch exceptions if node id is not in KG.
    # That would be a show stopper; let it stop the show.
    return node_collection

# Note: this function should be run only after the KG being passed in has a
# complete set of edges for all results. This function is necessary because
# collect_qg_nodes_for_res_elem will collect only those nodes that are bound to
# QG nodes; via auxiliary graphs, many more nodes can actually exist in the
# context of a result.
#
# Unless you need to collect only the result node bindings, use this function.

def collect_nodes_for_edge_collection(edge_collection: dict, orig_kg: dict, node_collection: dict) -> dict:
    for edge in edge_collection.values():
        ids = (edge['subject'], edge['object'])
        for id in ids:
            if id not in node_collection:
                node_collection[id] = orig_kg['nodes'][id]
    return node_collection

def get_sg_ids_for_edge(edge: dict) -> list:
    if 'attributes' in edge:
        for attr in edge['attributes']:
            if attr['attribute_type_id'] == 'biolink:support_graphs':
                return attr['value']
    return []


def collect_sg(sg_id: str, kg: dict, aux_graphs: dict, edge_collection: dict, sg_collection: dict) -> None:
    if sg_id in sg_collection:
        return

    sg_collection[sg_id] = aux_graphs[sg_id]
    for e in sg_collection[sg_id]['edges']:
        collect_edge(e, kg, aux_graphs, edge_collection, sg_collection)


def collect_edge(edge_id: str, kg: dict, aux_graphs: dict, edge_collection: dict, sg_collection: dict) -> None:
    if edge_id in edge_collection:
        return

    orig_edge = kg['edges'][edge_id]
    edge_collection[edge_id] = orig_edge
    sg_ids = get_sg_ids_for_edge(orig_edge)
    for id in sg_ids:
        collect_sg(id, kg, aux_graphs, edge_collection, sg_collection)


def collect_edges_and_sgs_for_res_elem(res_elem: dict, kg: dict, aux_graphs: dict,
    edge_collection: dict, sg_collection: dict) -> None:

    for anal in res_elem['analyses']:
        for eb_val in anal['edge_bindings'].values():
            for elem in eb_val:
                collect_edge(elem['id'], kg, aux_graphs, edge_collection, sg_collection)

        if 'support_graphs' in anal:
            for sg_id in anal['support_graphs']:
                collect_sg(sg_id, kg, aux_graphs, edge_collection, sg_collection)

def shrink_response(orig_trapi_response: dict, idx: int | tuple[int, ...] | range, include_non_msg=False) -> dict:
    # Convert single int to tuple for consistent processing
    if isinstance(idx, int):
        idx = (idx,)

    if include_non_msg:
        retval = copy_non_message_fields(orig_trapi_response)
        retval['fields']['data']['message'] = {}
    else:
        retval = {'fields': {'data': {'message': {}}}}

    orig_msg = orig_trapi_response['fields']['data']['message']
    orig_kg = orig_msg['knowledge_graph']
    orig_ag = orig_msg['auxiliary_graphs']
    orig_qg = orig_msg['query_graph']
    ret_nodes = {}
    ret_edges = {}
    ret_sgs = {}
    ret_results = []

    for i in idx:
        cur_res = orig_msg['results'][i]
        ret_results.append(cur_res)
        collect_edges_and_sgs_for_res_elem(cur_res, orig_kg, orig_ag, ret_edges, ret_sgs)
        collect_nodes_for_edge_collection(ret_edges, orig_kg, ret_nodes)

    ret_msg = retval['fields']['data']['message']
    ret_msg['query_graph'] = orig_msg['query_graph']
    ret_msg['knowledge_graph'] = {
        'nodes': ret_nodes,
        'edges': ret_edges
    }
    ret_msg['auxiliary_graphs'] = ret_sgs
    ret_msg['results'] = ret_results

    return retval

if __name__ == "__main__":
    import json
    import argparse

    def parse_args() -> argparse.Namespace:
        parser = argparse.ArgumentParser(description='Trim down TRAPI response files')
        parser.add_argument('-n', type=int, default=100, help='Number of results to include (default: 100)')
        parser.add_argument('-i', '--input', help='Input JSON file path of a TRAPI response')
        parser.add_argument('--start', type=int, help='Starting index in results array')
        parser.add_argument('--end', type=int, help='Ending index (exclusive) in results array')
        parser.add_argument('--list', type=str, help='Comma-separated list of indices, e.g. --list=9,18,202')
        parser.add_argument('--nonmsg', action='store_true', help='Include non-message fields in output')
        args = parser.parse_args()

        # Validate arguments
        if args.end is not None and args.start is None:
            parser.error("--end cannot be specified without --start")

        if args.end is not None and args.start is not None:
            if int(args.end) < int(args.start):
                parser.error("--end must be >= --start")

        return args

    # TODO: filter this range to cap at limit of len(results)
    def get_index_range(args) -> tuple[int, ...] | range:
        if args.list is not None:
            return tuple(int(num) for num in args.list.strip(',').split(',') if num.strip() != '')

        if args.start is None:
            return range(0, args.n) # note: not n-1, because that's how ranges work

        if args.end is None:
            return range(args.start, args.start + args.n) # ditto
        else:
            return range(args.start, args.end + 1)

    # begin main
    args = parse_args()
    idx_range = get_index_range(args)
    with open(args.input, 'r') as f:
        data = json.load(f)
    res = shrink_response(data, idx_range, args.nonmsg)
    print(json.dumps(res))
